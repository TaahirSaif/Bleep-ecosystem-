"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Activity, Shield, CuboidIcon as Cube, Brain, Link, UserCheck, Zap, Vote, BarChart3, ArrowRight } from 'lucide-react'
import { DownloadWhitepaperButton } from "./download-whitepaper-button"

const features = [
  {
    title: "Self-Healing Blockchain",
    description: "Say goodbye to downtime. BLEEP's self-healing blockchain autonomously detects and resolves issues, ensuring 99.99% uptime.",
    icon: Activity
  },
  {
    title: "Anti-Asset Loss Mechanism",
    description: "BLEEP introduces the first native anti-asset loss mechanism to recover lost or compromised digital assets safely.",
    icon: Shield
  },
  {
    title: "Programmable Asset Tokens (PAT)",
    description: "Empowering users with programmable, modular tokens that adapt to any business or personal need.",
    icon: Cube
  },
  {
    title: "AI-Driven Ecosystem",
    description: "BLEEP integrates AI at its core to enhance decision-making, improve network efficiency, and predict market trends.",
    icon: Brain
  },
  {
    title: "Interoperability",
    description: "Seamlessly connect with other blockchains for cross-chain functionality and transactions without barriers.",
    icon: Link
  },
  {
    title: "User-Friendly Tools",
    description: "No coding? No problem. BLEEP offers an intuitive interface that empowers everyone, from developers to casual users.",
    icon: UserCheck
  },
  {
    title: "Scalability and Security",
    description: "Handle thousands of transactions per second with military-grade security, ensuring a robust and scalable network.",
    icon: Zap
  },
  {
    title: "Hybrid Governance",
    description: "BLEEP combines decentralized and autonomous governance models, ensuring transparency and community empowerment.",
    icon: Vote
  },
  {
    title: "Custom Blockchain Explorer",
    description: "Track real-time metrics, transactions, and network activity with BLEEP's tailored blockchain explorer.",
    icon: BarChart3
  }
]

export function FeaturesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <motion.h1 
          className="text-4xl md:text-6xl font-bold text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          BLEEP: Redefining Blockchain with AI-Driven Innovation
        </motion.h1>

        <motion.div
          className="flex justify-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <DownloadWhitepaperButton />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <feature.icon className="w-6 h-6 text-blue-400" />
                    <span>{feature.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <h2 className="text-3xl font-bold mb-4">Explore BLEEP and join the future of blockchain technology today!</h2>
          <Button 
            size="lg" 
            className="bg-blue-500 hover:bg-blue-600 text-white"
          >
            Learn More <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </motion.div>
      </div>
    </div>
  )
}


"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ArrowRight, Zap, Shield, Brain, Link, CuboidIcon as Cube } from 'lucide-react'

const innovations = [
  {
    title: "Self-Healing Blockchain",
    description: "BLEEP's blockchain autonomously detects and resolves issues, ensuring unparalleled uptime and reliability.",
    icon: Zap
  },
  {
    title: "Anti-Asset Loss Mechanism",
    description: "A groundbreaking feature that allows for the recovery of lost or compromised digital assets, enhancing security and user confidence.",
    icon: Shield
  },
  {
    title: "AI-Driven Ecosystem",
    description: "Integrated AI that enhances decision-making, improves network efficiency, and provides personalized experiences for users.",
    icon: Brain
  },
  {
    title: "Seamless Interoperability",
    description: "BLEEP connects effortlessly with other blockchains, enabling cross-chain functionality and expanding the ecosystem's reach.",
    icon: Link
  },
  {
    title: "Programmable Asset Tokens (PATs)",
    description: "Customizable tokens that adapt to any business or personal need, revolutionizing asset management and creation.",
    icon: Cube
  }
]

export function InnovationsModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] bg-gray-900 text-white">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold">BLEEP Innovations: Redefining Blockchain Technology</DialogTitle>
          <DialogDescription>
            Discover the cutting-edge features that set BLEEP apart and drive the future of decentralized ecosystems.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="mt-6 max-h-[60vh]">
          <div className="space-y-8">
            <section>
              <h2 className="text-2xl font-bold mb-4">Our Revolutionary Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {innovations.map((innovation, index) => (
                  <Card key={innovation.title} className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <innovation.icon className="w-6 h-6 text-blue-400" />
                        <span>{innovation.title}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300">{innovation.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">The Impact of Our Innovations</h2>
              <p className="text-gray-300 mb-4">
                BLEEP's innovations are not just technological advancements; they're reshaping the blockchain landscape:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-gray-300">
                <li>Enhanced security and trust in digital asset management</li>
                <li>Improved scalability and performance for enterprise-level applications</li>
                <li>Seamless integration of AI for smarter, more efficient blockchain operations</li>
                <li>Expanded interoperability, breaking down barriers between different blockchain ecosystems</li>
                <li>Unprecedented flexibility in token creation and asset representation</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">Join the Innovation Journey</h2>
              <p className="text-gray-300 mb-4">
                Be part of the revolution that's shaping the future of blockchain technology. Whether you're a developer, 
                entrepreneur, or blockchain enthusiast, there's a place for you in the BLEEP ecosystem.
              </p>
              <div className="flex justify-center space-x-4">
                <Button size="lg" onClick={onClose}>
                  Explore Developer Tools <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button size="lg" variant="outline" onClick={onClose}>
                  Join Our Community <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}


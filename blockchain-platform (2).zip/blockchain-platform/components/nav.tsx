"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, MessageSquare } from 'lucide-react'
import { GlowButton } from "@/components/ui/glow-button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Logo } from "./logo"
import { EcosystemModal } from "./ecosystem-modal"

export function Nav() {
  const [isOpen, setIsOpen] = useState(false)
  const [isEcosystemModalOpen, setIsEcosystemModalOpen] = useState(false)

  return (
    <nav className="fixed top-0 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50">
      <div className="container flex h-16 items-center justify-between">
        <Logo />
        <div className="hidden md:flex items-center gap-6">
          <button 
            className="text-sm font-medium hover:text-primary"
            onClick={() => setIsEcosystemModalOpen(true)}
          >
            Ecosystem
          </button>
          <Link href="#features" className="text-sm font-medium hover:text-primary">
            Features
          </Link>
          <Link href="#developers" className="text-sm font-medium hover:text-primary">
            Developers
          </Link>
          <Link href="#community" className="text-sm font-medium hover:text-primary">
            Community
          </Link>
          <Link href="/bleep-chat" className="text-sm font-medium hover:text-primary flex items-center">
            <MessageSquare className="w-4 h-4 mr-1" />
            BLEEPchat
          </Link>
          <Link href="/app" className="inline-block">
            <GlowButton>Launch App</GlowButton>
          </Link>
        </div>
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <GlowButton variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </GlowButton>
          </SheetTrigger>
          <SheetContent side="right">
            <div className="flex flex-col space-y-4">
              <button 
                className="text-sm font-medium"
                onClick={() => {
                  setIsOpen(false)
                  setIsEcosystemModalOpen(true)
                }}
              >
                Ecosystem
              </button>
              <Link href="#features" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                Features
              </Link>
              <Link href="#developers" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                Developers
              </Link>
              <Link href="#community" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                Community
              </Link>
              <Link href="/bleep-chat" className="text-sm font-medium flex items-center" onClick={() => setIsOpen(false)}>
                <MessageSquare className="w-4 h-4 mr-1" />
                BLEEPchat
              </Link>
              <Link href="/app" className="inline-block">
                <GlowButton onClick={() => setIsOpen(false)}>Launch App</GlowButton>
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
      <EcosystemModal isOpen={isEcosystemModalOpen} onClose={() => setIsEcosystemModalOpen(false)} />
    </nav>
  )
}


import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { VisuallyHidden } from "@/components/ui/visually-hidden"

interface ViewInnovationsModalProps {
  isOpen: boolean
  onClose: () => void
}

export function ViewInnovationsModal({ isOpen, onClose }: ViewInnovationsModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <VisuallyHidden>
            <DialogTitle>BLEEP Innovations: Redefining Blockchain Technology</DialogTitle>
          </VisuallyHidden>
          <DialogDescription>
            Discover the cutting-edge features that set BLEEP apart and drive the future of decentralized ecosystems.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="submit" onClick={onClose}>Explore More</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


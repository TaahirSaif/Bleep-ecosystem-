"use client"

import { useRef, useEffect } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Sphere, Line, OrbitControls } from '@react-three/drei'
import * as THREE from 'three'

function Node({ position }: { position: [number, number, number] }) {
  return (
    <Sphere args={[0.1, 16, 16]} position={position}>
      <meshBasicMaterial color="#00ff00" />
    </Sphere>
  )
}

function Connection({ start, end }: { start: [number, number, number]; end: [number, number, number] }) {
  return (
    <Line
      points={[start, end]}
      color="#00ff00"
      lineWidth={1}
      dashed={true}
      dashSize={0.1}
      dashScale={1}
      dashOffset={0}
    />
  )
}

function AnimatedConnections() {
  const lineRef = useRef<THREE.LineSegments>(null)

  useFrame((state) => {
    if (lineRef.current) {
      lineRef.current.rotation.x = state.clock.getElapsedTime() * 0.1
      lineRef.current.rotation.y = state.clock.getElapsedTime() * 0.15
    }
  })

  return (
    <group ref={lineRef}>
      <Connection start={[-1, -1, -1]} end={[1, 1, 1]} />
      <Connection start={[-1, 1, 1]} end={[1, -1, -1]} />
      <Connection start={[1, -1, 1]} end={[-1, 1, -1]} />
      <Connection start={[1, 1, -1]} end={[-1, -1, 1]} />
    </group>
  )
}

function BlockchainScene() {
  return (
    <>
      <Node position={[-1, -1, -1]} />
      <Node position={[1, 1, 1]} />
      <Node position={[-1, 1, 1]} />
      <Node position={[1, -1, -1]} />
      <Node position={[1, -1, 1]} />
      <Node position={[-1, 1, -1]} />
      <Node position={[1, 1, -1]} />
      <Node position={[-1, -1, 1]} />
      <AnimatedConnections />
      <OrbitControls enableZoom={false} enablePan={false} enableRotate={true} />
    </>
  )
}

export function BlockchainBackground() {
  return (
    <div className="absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <BlockchainScene />
      </Canvas>
    </div>
  )
}


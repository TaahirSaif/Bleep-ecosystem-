import { Button } from "@/components/ui/button"
import { FileDown } from 'lucide-react'

export function DownloadWhitepaperButton() {
  const handleDownload = () => {
    // In a real implementation, this would trigger the download of the whitepaper PDF
    // For now, we'll just log a message
    console.log("Downloading whitepaper...")
    // You would typically use something like this:
    // window.open("/path-to-your-whitepaper.pdf", "_blank")
  }

  return (
    <Button 
      onClick={handleDownload}
      className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-2 px-4 rounded-full shadow-lg hover:shadow-xl transition duration-300 flex items-center space-x-2"
    >
      <FileDown className="w-5 h-5" />
      <span>Download Whitepaper</span>
    </Button>
  )
}


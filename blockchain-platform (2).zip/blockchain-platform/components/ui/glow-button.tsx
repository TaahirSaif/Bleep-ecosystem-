import * as React from "react"
import { cn } from "@/lib/utils"
import { Button, ButtonProps } from "@/components/ui/button"

export interface GlowButtonProps extends ButtonProps {}

const GlowButton = React.forwardRef<HTMLButtonElement, GlowButtonProps>(
  ({ className, ...props }, ref) => {
    return (
      <Button
        className={cn(
          "relative overflow-hidden transition-all duration-300 ease-in-out",
          "before:absolute before:inset-0 before:bg-gradient-to-r before:from-primary-400 before:to-primary-600 before:opacity-0 before:transition-opacity before:duration-300 before:ease-in-out before:blur-xl",
          "hover:before:opacity-70",
          "active:before:opacity-100",
          "after:absolute after:inset-0 after:bg-gradient-to-r after:from-primary-400 after:to-primary-600 after:opacity-0 after:transition-opacity after:duration-300 after:ease-in-out after:blur-sm",
          "hover:after:opacity-70",
          "active:after:opacity-100",
          "hover:text-primary-foreground",
          "hover:shadow-lg hover:shadow-primary/50",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
GlowButton.displayName = "GlowButton"

export { GlowButton }


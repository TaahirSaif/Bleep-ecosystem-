"use client"

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, Phone, Video, Send, PlusCircle, Settings } from 'lucide-react'

type Message = {
  id: string
  sender: string
  content: string
  timestamp: Date
}

export function BLEEPchat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')

  useEffect(() => {
    // Simulating fetching initial messages
    setMessages([
      { id: '1', sender: 'Alice', content: 'Hey, how are you?', timestamp: new Date() },
      { id: '2', sender: 'Bob', content: 'I\'m good, thanks! How about you?', timestamp: new Date() },
    ])
  }, [])

  const sendMessage = () => {
    if (input.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        sender: 'You',
        content: input,
        timestamp: new Date(),
      }
      setMessages(prev => [...prev, newMessage])
      setInput('')
    }
  }

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">BLEEPchat</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="messages">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="messages">
              <MessageSquare className="w-5 h-5 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="voice">
              <Phone className="w-5 h-5 mr-2" />
              Voice
            </TabsTrigger>
            <TabsTrigger value="video">
              <Video className="w-5 h-5 mr-2" />
              Video
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-5 h-5 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>
          <TabsContent value="messages" className="space-y-4">
            <ScrollArea className="h-[400px] w-full rounded-md border p-4">
              {messages.map(message => (
                <div key={message.id} className="flex items-start space-x-2 mb-4">
                  <Avatar>
                    <AvatarFallback>{message.sender[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{message.sender}</p>
                    <p>{message.content}</p>
                    <p className="text-sm text-gray-500">{message.timestamp.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </ScrollArea>
            <div className="flex space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              />
              <Button onClick={sendMessage}>
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="voice">
            <div className="text-center py-8">
              <Phone className="w-12 h-12 mx-auto mb-4" />
              <p>Voice calls coming soon!</p>
            </div>
          </TabsContent>
          <TabsContent value="video">
            <div className="text-center py-8">
              <Video className="w-12 h-12 mx-auto mb-4" />
              <p>Video calls coming soon!</p>
            </div>
          </TabsContent>
          <TabsContent value="settings">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Chat Settings</h3>
              <div className="flex items-center space-x-2">
                <Input type="text" placeholder="Enter your display name" />
                <Button>Update</Button>
              </div>
              <div>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" />
                  <span>Enable end-to-end encryption</span>
                </label>
              </div>
              <div>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" />
                  <span>Allow token transfers in chat</span>
                </label>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}


"use client"

import { motion } from "framer-motion"
import { Activity, Database, Network, Users } from 'lucide-react'
import { Card, CardContent } from "@/components/ui/card"

const stats = [
  {
    title: "TPS",
    value: "10,000+",
    icon: Activity,
    description: "Transactions per second"
  },
  {
    title: "Nodes",
    value: "5,000+",
    icon: Network,
    description: "Active network nodes"
  },
  {
    title: "Supply",
    value: "100M",
    icon: Database,
    description: "Circulating supply"
  },
  {
    title: "Users",
    value: "1M+",
    icon: Users,
    description: "Active users"
  }
]

export function Stats() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <stat.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold">{stat.value}</h3>
                    <p className="text-sm text-muted-foreground">{stat.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}


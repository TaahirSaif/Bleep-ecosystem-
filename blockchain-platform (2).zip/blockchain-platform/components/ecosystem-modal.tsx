"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ArrowRight, Shield, Coins, MessageSquare, CuboidIcon as Cube, Code, BarChart3, VoteIcon, Brain } from 'lucide-react'

const ecosystemComponents = [
  { title: "BLEEP Blockchain", description: "The foundation of the ecosystem — a self-amending, scalable, and secure blockchain designed for the future.", icon: Shield },
  { title: "BLP Token", description: "The ecosystem's native currency, fueling transactions, governance, and innovation.", icon: Coins },
  { title: "BLEEPchat", description: "A decentralized, offline peer-to-peer communication platform enabling secure messaging and transactions.", icon: MessageSquare },
  { title: "Programmable Asset Tokens (PATs)", description: "Revolutionizing asset management with customizable tokens for various use cases.", icon: Cube },
  { title: "Developer Hub", description: "A comprehensive toolkit for developers to build, test, and deploy decentralized applications (dApps).", icon: Code },
  { title: "BLEEP Explorer", description: "An advanced blockchain explorer providing real-time insights, metrics, and analytics.", icon: BarChart3 },
  { title: "Governance Hub", description: "Hybrid governance mechanisms enabling users to vote, propose changes, and influence the ecosystem's future.", icon: VoteIcon },
  { title: "AI Integration", description: "BLEEP AI for advanced insights, automation, and personalized user experiences.", icon: Brain },
]

const useCases = [
  "DeFi solutions: lending, staking, and yield farming.",
  "NFT creation and trading.",
  "Supply chain transparency and tracking.",
  "Decentralized communication and asset recovery."
]

export function EcosystemModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] bg-gray-900 text-white">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold">The BLEEP Ecosystem: A Revolutionary AI-Powered Decentralized Universe</DialogTitle>
          <DialogDescription>
            Explore a groundbreaking ecosystem that integrates advanced blockchain technologies, AI, and real-world solutions to redefine the future of decentralization.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="mt-6 max-h-[60vh]">
          <div className="space-y-8">
            <section>
              <h2 className="text-2xl font-bold mb-4">What Makes BLEEP Unique?</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>Self-healing blockchain with autonomous recovery</li>
                <li>AI-driven decision-making for governance and optimization</li>
                <li>Offline peer-to-peer communication with BLEEPchat</li>
                <li>Seamless interoperability with other blockchains and beyond</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">Ecosystem Components</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ecosystemComponents.map((component, index) => (
                  <Card key={component.title} className="bg-gray-800 border-gray-700">
                    <CardContent className="p-4 flex items-start space-x-4">
                      <component.icon className="w-6 h-6 text-blue-400 flex-shrink-0" />
                      <div>
                        <h3 className="font-bold">{component.title}</h3>
                        <p className="text-sm text-gray-300">{component.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">Real-World Impact</h2>
              <p className="mb-4">The BLEEP ecosystem supports diverse use cases, including:</p>
              <ul className="list-disc pl-5 space-y-2">
                {useCases.map((useCase, index) => (
                  <li key={index}>{useCase}</li>
                ))}
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">The BLEEP Workflow</h2>
              <p className="mb-4">The BLEEP ecosystem components interact seamlessly:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>BLP tokens fuel PAT transactions</li>
                <li>BLEEPchat integrates with the blockchain for secure messaging</li>
                <li>Interoperability features bridge different blockchains and traditional systems</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">Ecosystem in Action</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-center">
                      <span className="text-2xl font-bold">1,234,567</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-center">Total Transactions Processed</p>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-center">
                      <span className="text-2xl font-bold">50,000+</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-center">Active Users/Nodes</p>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-center">
                      <span className="text-2xl font-bold">10,000,000</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-center">BLP Tokens Staked</p>
                  </CardContent>
                </Card>
              </div>
            </section>
          </div>
        </ScrollArea>
        <div className="mt-6 flex justify-center space-x-4">
          <Button size="lg" onClick={onClose}>
            Join the Revolution <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
          <Button size="lg" variant="outline" onClick={onClose}>
            Get Started as a Developer <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}


"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { BlockchainBackground } from "./blockchain-background"
import { JoinRevolutionModal } from "./join-revolution-modal"
import { ViewInnovationsModal } from "./view-innovations-modal"
import { StartJourneyModal } from "./start-journey-modal"

export function Hero() {
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false)
  const [isInnovationsModalOpen, setIsInnovationsModalOpen] = useState(false)
  const [isStartJourneyModalOpen, setIsStartJourneyModalOpen] = useState(false)

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <BlockchainBackground />
      <div className="relative z-10 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center space-y-6"
        >
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-white">
            Welcome to the Future of Blockchain
          </h1>
          <p className="text-xl text-gray-300 max-w-[600px] mx-auto">
            Experience the next generation of decentralized technology with our self-healing blockchain
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" onClick={() => setIsStartJourneyModalOpen(true)}>Start Your Journey</Button>
            <Button size="lg" variant="outline" onClick={() => window.open("https://explorer.bleep.com", "_blank")}>Explore the Network</Button>
            <Button size="lg" variant="secondary" onClick={() => setIsInnovationsModalOpen(true)}>View Innovations</Button>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <Button 
              size="lg" 
              variant="default" 
              className="mt-8 px-8 py-6 text-lg font-semibold"
              onClick={() => setIsJoinModalOpen(true)}
            >
              Join the Revolution
            </Button>
          </motion.div>
        </motion.div>
      </div>
      <JoinRevolutionModal isOpen={isJoinModalOpen} onClose={() => setIsJoinModalOpen(false)} />
      <ViewInnovationsModal isOpen={isInnovationsModalOpen} onClose={() => setIsInnovationsModalOpen(false)} />
      <StartJourneyModal isOpen={isStartJourneyModalOpen} onClose={() => setIsStartJourneyModalOpen(false)} />
    </div>
  )
}


"use client"

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

export function BleepWallet() {
  const [address, setAddress] = useState("")
  const [balance, setBalance] = useState("0")
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [network, setNetwork] = useState("BLEEP")

  const fetchBalance = async () => {
    try {
      const response = await fetch(`/api/balance?address=${address}`)
      const data = await response.json()
      setBalance(data.balance)
    } catch (error) {
      toast({
        title: "Error",
        description: "Unable to fetch balance.",
        variant: "destructive",
      })
    }
  }

  const sendTransaction = async (type: 'send' | 'bridge' | 'transfer') => {
    try {
      const endpoint = type === "bridge" ? "/api/bridge" : type === "transfer" ? "/api/transfer" : "/api/transaction"
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sender: address, recipient, amount, network }),
      })
      const data = await response.json()
      if (data.success) {
        toast({
          title: "Success",
          description: `${type.charAt(0).toUpperCase() + type.slice(1)} completed!`,
        })
        fetchBalance()
      } else {
        toast({
          title: "Error",
          description: `${type.charAt(0).toUpperCase() + type.slice(1)} failed.`,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Transaction error.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>BLEEP Wallet</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input
          placeholder="Your Wallet Address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
        <Button onClick={fetchBalance}>Check Balance</Button>
        <div className="text-center text-lg font-bold">Balance: {balance} BLP</div>
        <Input
          placeholder="Recipient Address"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
        />
        <Input
          placeholder="Amount to Send"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          type="number"
        />
        <Select value={network} onValueChange={setNetwork}>
          <SelectTrigger>
            <SelectValue placeholder="Select Network" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="BLEEP">BLEEP Network</SelectItem>
            <SelectItem value="Ethereum">Ethereum</SelectItem>
            <SelectItem value="BSC">Binance Smart Chain</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex justify-between">
          <Button onClick={() => sendTransaction('send')}>Send</Button>
          <Button onClick={() => sendTransaction('bridge')}>Bridge</Button>
          <Button onClick={() => sendTransaction('transfer')}>Transfer</Button>
        </div>
      </CardContent>
    </Card>
  )
}


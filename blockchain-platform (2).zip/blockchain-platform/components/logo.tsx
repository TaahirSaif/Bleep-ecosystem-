import Image from "next/image"
import Link from "next/link"

export function Logo() {
  return (
    <Link href="/" className="flex items-center space-x-2">
      <Image 
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-tV1Se6fTOftTWIeV6t2ECE2qRhLqQX.jpeg"
        alt="BLEEP Logo" 
        width={40} 
        height={40}
        className="rounded-full"
      />
      <span className="font-bold text-xl text-white">BLEEP</span>
    </Link>
  )
}


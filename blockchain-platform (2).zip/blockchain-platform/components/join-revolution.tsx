"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Code, Users, VoteIcon, Coins } from 'lucide-react'

const opportunities = [
  { title: "Shape the Future", description: "Participate in decision-making through hybrid governance.", icon: VoteIcon },
  { title: "Earn Rewards", description: "Engage in activities like staking, development, and community contributions.", icon: Coins },
  { title: "Access Cutting-Edge Technology", description: "Experience advanced features like self-healing blockchain, AI integration, and offline transactions.", icon: Code },
  { title: "Learn and Grow", description: "Be part of a community that shares knowledge and fosters innovation.", icon: Users },
  { title: "Be a Leader", description: "Help redefine blockchain standards with the world's first self-amending blockchain.", icon: ArrowRight },
]

const ctas = [
  { title: "Join the Community", description: "Connect with innovators like you on BLEEPchat and official forums.", buttonText: "Join the Community" },
  { title: "Become a Developer", description: "Shape the ecosystem by building apps or improving core features.", buttonText: "Developer Hub" },
  { title: "Participate in Governance", description: "Have your voice heard in key decisions through BLEEP's hybrid governance model.", buttonText: "Learn About Governance" },
  { title: "Invest in the Future", description: "Support BLEEP by acquiring BLP tokens and contributing to our decentralized future.", buttonText: "Get BLP Tokens" },
]

export function JoinRevolution() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <motion.h1 
          className="text-4xl md:text-6xl font-bold text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Join the BLEEP Revolution
        </motion.h1>

        <motion.p
          className="text-xl text-center mb-16 max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          BLEEP is not just a blockchain; it's a vision for the future. We're building the most advanced, user-friendly, and innovative ecosystem that empowers individuals, developers, and businesses to take control of their digital assets and ideas. Be part of this groundbreaking journey today.
        </motion.p>

        <h2 className="text-3xl font-bold mb-8 text-center">Why Join the Revolution?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {opportunities.map((opportunity, index) => (
            <motion.div
              key={opportunity.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-gray-800 border-gray-700 h-full">
                <CardContent className="p-6 flex flex-col h-full">
                  <opportunity.icon className="w-12 h-12 text-blue-400 mb-4" />
                  <h3 className="text-xl font-bold mb-2">{opportunity.title}</h3>
                  <p className="text-gray-300 flex-grow">{opportunity.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <h2 className="text-3xl font-bold mb-8 text-center">Get Involved</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {ctas.map((cta, index) => (
            <motion.div
              key={cta.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">{cta.title}</h3>
                  <p className="text-gray-300 mb-4">{cta.description}</p>
                  <Button className="w-full">{cta.buttonText}</Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Real-Time BLEEP Metrics</h2>
          <div className="flex justify-center space-x-8">
            <div>
              <span className="text-4xl font-bold">1,234,567</span>
              <p>Active Users</p>
            </div>
            <div>
              <span className="text-4xl font-bold">9,876,543</span>
              <p>Transactions</p>
            </div>
            <div>
              <span className="text-4xl font-bold">5,432</span>
              <p>BLEEP Nodes</p>
            </div>
          </div>
        </div>

        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-8">What Our Community Says</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <p className="italic mb-4">"BLEEP has revolutionized the way I think about blockchain. The self-healing feature gives me peace of mind, and the community is incredibly supportive."</p>
                <p className="font-bold">- Alex, Blockchain Developer</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <p className="italic mb-4">"As a business owner, BLEEP's programmable asset tokens have opened up new possibilities for my company. The future is here, and it's BLEEP!"</p>
                <p className="font-bold">- Sarah, Entrepreneur</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <h2 className="text-3xl font-bold mb-4">Don't Just Witness the Revolution — Lead It. Together, We'll Build the Future.</h2>
          <Button size="lg" className="mt-4 px-8 py-6 text-lg font-semibold">
            Join the Revolution <ArrowRight className="ml-2 w-6 h-6" />
          </Button>
        </motion.div>
      </div>
    </div>
  )
}


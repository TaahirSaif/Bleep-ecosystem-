import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Twitter, Linkedin, Github, MessageCircle, BookOpen } from 'lucide-react'

const navigationLinks = [
  {
    category: "Explore",
    links: [
      { name: "Home", href: "/" },
      { name: "About BLEEP", href: "/about" },
      { name: "View Innovations", href: "/innovations" },
      { name: "Start Your Journey", href: "/start" },
      { name: "Roadmap", href: "/roadmap" },
    ]
  },
  {
    category: "Ecosystem",
    links: [
      { name: "BLEEP Wallet", href: "/wallet" },
      { name: "BLEEP Explorer", href: "/explorer" },
      { name: "BLEEPchat", href: "/chat" },
      { name: "Developer Resources", href: "/developers" },
      { name: "Tokenomics", href: "/tokenomics" },
    ]
  },
  {
    category: "Community",
    links: [
      { name: "Blog", href: "/blog" },
      { name: "FAQs", href: "/faqs" },
      { name: "Forums", href: "/forums" },
      { name: "Social Channels", href: "/social" },
    ]
  },
  {
    category: "Legal",
    links: [
      { name: "Privacy Policy", href: "/privacy" },
      { name: "Terms of Service", href: "/terms" },
      { name: "Disclaimer", href: "/disclaimer" },
    ]
  },
]

const socialLinks = [
  { name: "Twitter", icon: Twitter, href: "https://twitter.com/BLEEP" },
  { name: "LinkedIn", icon: Linkedin, href: "https://linkedin.com/company/BLEEP" },
  { name: "Discord", icon: MessageCircle, href: "https://discord.gg/BLEEP" },
  { name: "GitHub", icon: Github, href: "https://github.com/BLEEP" },
  { name: "Medium", icon: BookOpen, href: "https://medium.com/BLEEP" },
]

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {navigationLinks.map((category) => (
            <div key={category.category}>
              <h3 className="text-lg font-semibold mb-4">{category.category}</h3>
              <ul className="space-y-2">
                {category.links.map((link) => (
                  <li key={link.name}>
                    <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
            <ul className="space-y-2">
              <li>Support: support@bleepchain.com</li>
              <li>General Inquiries: info@bleepchain.com</li>
              <li>Developer Assistance: devsupport@bleepchain.com</li>
            </ul>
            <Button className="mt-4">Contact Us</Button>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Stay Updated on the Latest Innovations!</h3>
            <p className="mb-4">Get the latest updates, announcements, and exclusive insights into the BLEEP ecosystem.</p>
            <div className="flex space-x-2">
              <Input type="email" placeholder="Enter your email" className="max-w-xs" />
              <Button>Subscribe Now</Button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap justify-between items-center mb-8">
          <div className="flex space-x-4 mb-4 md:mb-0">
            {socialLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-gray-400 hover:text-white transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <link.icon className="w-6 h-6" />
                <span className="sr-only">{link.name}</span>
              </a>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <Select>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-2">
              <Switch id="dark-mode" />
              <Label htmlFor="dark-mode">Dark Mode</Label>
            </div>
          </div>
        </div>

        <div className="text-center text-sm text-gray-400">
          <p>© 2024 BLEEP Blockchain Ecosystem. All Rights Reserved.</p>
          <p className="mt-2">"Empowering Innovation, Redefining Blockchain."</p>
        </div>
      </div>
    </footer>
  )
}


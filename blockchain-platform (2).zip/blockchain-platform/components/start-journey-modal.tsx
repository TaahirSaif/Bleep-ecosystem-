import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { VisuallyHidden } from "@/components/ui/visually-hidden"

interface StartJourneyModalProps {
  isOpen: boolean
  onClose: () => void
}

export function StartJourneyModal({ isOpen, onClose }: StartJourneyModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <VisuallyHidden>
            <DialogTitle>Your Blockchain Adventure Begins Here!</DialogTitle>
          </VisuallyHidden>
          <DialogDescription>
            Discover the groundbreaking BLEEP ecosystem, designed to empower users with innovative technology, AI-driven solutions, and a user-friendly experience.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="submit" onClick={onClose}>Start Your Journey</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


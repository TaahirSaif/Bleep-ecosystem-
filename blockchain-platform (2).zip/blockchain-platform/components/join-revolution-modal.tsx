import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { VisuallyHidden } from "@/components/ui/visually-hidden"

interface JoinRevolutionModalProps {
  isOpen: boolean
  onClose: () => void
}

export function JoinRevolutionModal({ isOpen, onClose }: JoinRevolutionModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <VisuallyHidden>
            <DialogTitle>Join the BLEEP Revolution</DialogTitle>
          </VisuallyHidden>
          <DialogDescription>
            BLEEP is not just a blockchain; it's a vision for the future. We're building the most advanced, user-friendly, and innovative ecosystem that empowers individuals, developers, and businesses to take control of their digital assets and ideas.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="submit" onClick={onClose}>Join Now</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


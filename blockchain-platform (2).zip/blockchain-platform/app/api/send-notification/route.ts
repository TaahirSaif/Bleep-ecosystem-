import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  const { deviceToken, message } = await request.json()

  // In a real implementation, you would use the Firebase Admin SDK here to send the notification
  console.log(`Sending notification to ${deviceToken}: ${message}`)

  return NextResponse.json({ success: true, message: 'Notification sent' })
}


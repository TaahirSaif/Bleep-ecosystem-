import { NextResponse } from 'next/server'
import speakeasy from 'speakeasy'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

// Mock user database
const users = [
  {
    username: 'admin',
    password: '$2a$10$XOPbrlUPQdwdJUpSrIF6X.LbE14qsMmKGhM1A8W9iqDp1Ia5U5Tm.',  // 'password'
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    roles: ['Admin', 'User']
  },
  {
    username: 'user',
    password: '$2a$10$XOPbrlUPQdwdJUpSrIF6X.LbE14qsMmKGhM1A8W9iqDp1Ia5U5Tm.',  // 'password'
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    roles: ['User']
  }
]

export async function POST(request: Request) {
  const { username, password, token } = await request.json()
  
  const user = users.find(u => u.username === username)
  
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return NextResponse.json({ message: 'Invalid credentials' }, { status: 400 })
  }

  const valid = speakeasy.totp.verify({
    secret: user.mfaSecret,
    encoding: 'base32',
    token: token
  })

  if (!valid) {
    return NextResponse.json({ message: 'Invalid MFA token' }, { status: 400 })
  }

  const jwtToken = jwt.sign({ username: user.username, roles: user.roles }, process.env.JWT_SECRET!)
  return NextResponse.json({ token: jwtToken })
}


import { NextResponse } from 'next/server'

// Using the mock product database from the admin products route

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  const priceRange = searchParams.get('priceRange')?.split(',').map(Number)
  const searchQuery = searchParams.get('searchQuery')

  let filteredProducts = [...products]

  if (category) {
    filteredProducts = filteredProducts.filter(p => p.category === category)
  }

  if (priceRange) {
    filteredProducts = filteredProducts.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
  }

  if (searchQuery) {
    filteredProducts = filteredProducts.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
  }

  return NextResponse.json(filteredProducts)
}


import { NextResponse } from 'next/server'
import Web3 from 'web3'

const web3 = new Web3(process.env.INFURA_URL!)
const contractABI = [/* Your contract ABI here */]
const contractAddress = process.env.CONTRACT_ADDRESS!
const contract = new web3.eth.Contract(contractABI, contractAddress)

export async function POST(request: Request) {
  const { senderAddress, amount, receiverAddress } = await request.json()

  try {
    const tx = {
      from: senderAddress,
      to: contractAddress,
      data: contract.methods.transfer(receiverAddress, web3.utils.toWei(amount, 'ether')).encodeABI(),
      gas: 2000000
    }

    const signedTx = await web3.eth.accounts.signTransaction(tx, process.env.PRIVATE_KEY!)
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction!)
    
    return NextResponse.json({ success: true, transactionHash: receipt.transactionHash })
  } catch (error) {
    console.error('Transaction error:', error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}


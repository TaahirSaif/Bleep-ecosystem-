import { NextResponse } from 'next/server'
import nlp from 'compromise'

export async function POST(request: Request) {
  const { message } = await request.json()

  const doc = nlp(message)
  const entities = doc.topics().out('array')
  
  if (entities.includes('token balance')) {
    // In a real implementation, you would fetch the actual token balance here
    return NextResponse.json({ response: 'Your current token balance is 1000 BLP.' })
  }

  return NextResponse.json({ response: 'I didn\'t understand that. Can you clarify?' })
}


import { NextResponse } from 'next/server'
import { ethers } from 'ethers'

const provider = new ethers.providers.JsonRpcProvider("https://rpc.bleep.network")
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY!, provider)

export async function POST(request: Request) {
  const { sender, recipient, amount } = await request.json()

  if (!sender || !recipient || !amount) {
    return NextResponse.json({ error: 'Sender, recipient, and amount are required' }, { status: 400 })
  }

  try {
    const tx = await wallet.sendTransaction({
      to: recipient,
      value: ethers.utils.parseEther(amount),
    })
    await tx.wait()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Transaction failed:', error)
    return NextResponse.json({ success: false, error: 'Transaction failed' }, { status: 500 })
  }
}


import { NextResponse } from 'next/server'

// Mock product database
let products: any[] = []

export async function POST(request: Request) {
  const { name, price, category, description } = await request.json()

  const product = { id: Date.now(), name, price, category, description }
  products.push(product)

  return NextResponse.json({ success: true, product })
}


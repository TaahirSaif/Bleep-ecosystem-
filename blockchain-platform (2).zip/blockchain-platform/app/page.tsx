import { Nav } from "@/components/nav"
import { Hero } from "@/components/hero"
import { Stats } from "@/components/stats"
import { FeaturesPage } from "@/components/features-page"
import { Footer } from "@/components/footer"
import { BleepAIChatbot } from "@/components/bleep-ai-chatbot"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col bg-black">
      <Nav />
      <Hero />
      <Stats />
      <FeaturesPage />
      <Footer />
      <BleepAIChatbot />
    </main>
  )
}

